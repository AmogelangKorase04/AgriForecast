function RedirectToHomePage() {
    window.location.href = "home.html";
}

function valid(result) {
    if (result == "success") {
        RedirectToHomePage()
    }
    else if (result == "again") {
        alert("wrong password")
    }
    else {
        alert("wrong username")
    }
}

function login() {
    let user = document.getElementById("name").value;
    let password = document.getElementById("pass").value;

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var raw = JSON.stringify({"user":user,"password":password});

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };

    fetch("https://f6ulgapabi.execute-api.us-east-1.amazonaws.com/dev", requestOptions)
    .then(response => response.text())
    .then(result => valid(JSON.parse(result).body))
    .catch(error => console.log('error', error));
}

function signup() {
    let user = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("pass").value;

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var raw = JSON.stringify({"user":user,"email":email,"password":password});

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };

    fetch("https://ceprpxo2lh.execute-api.us-east-1.amazonaws.com/dev", requestOptions)
    .then(response => response.text())
    .then(result => RedirectToHomePage())
    .catch(error => console.log('error', error));
}